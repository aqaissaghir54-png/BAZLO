plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.gms.google-services")
}
android {
    namespace = "com.bazlo.admin"
    compileSdk = 35
    defaultConfig { applicationId = "com.bazlo.admin"; minSdk = 24; targetSdk = 35; versionCode = 4; versionName = "4.0" }
}
dependencies {
    implementation(project(":shared"))
    implementation(platform("com.google.firebase:firebase-bom:34.19.0"))
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-firestore")
}
